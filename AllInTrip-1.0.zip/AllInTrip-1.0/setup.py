from distutils.core import setup
setup(name='AllInTrip',
      version='1.0',
      py_modules=['AllInTrip','excel','gmail','mysmtplib','SeperatedFunction'],
      data_files=[('AllInTrip',['resource.zip','spam.pyd'])]
      )
